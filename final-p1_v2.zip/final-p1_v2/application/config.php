<?php

define('DEFAULT_VIEW', 'home');//set this to any page to be the default home page
define('BASE_URL', 'http://corsair.cs.iupui.edu:21791/CIT313/SP2018/final-p1_v2/');

//database info
define('DB_HOST', 'localhost');
define('DB_USER', 'joaschwe');
define('DB_PASS', 'joaschwe');
define('DB_NAME', 'joaschwe_db');

define('REQFIELD', '<font color="#FF0000">*</font>');
?>