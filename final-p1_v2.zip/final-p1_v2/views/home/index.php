<?php include('views/elements/header.php'); ?>

    <div class="container">
        <div class="page-header">
            <h1>Latest Trends in Technology</h1>
        </div>

        <div style="width: 60%;">
            <img style="width: 100%;" src="<?php echo BASE_URL?>views/img/techtrends_v1.png" alt="tech trends banner">
        </div>
        <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus in aliquam est, id cursus diam. In molestie sollicitudin lectus, quis convallis est hendrerit nec. Nam ut enim quis ex rutrum elementum at eu enim. Curabitur rutrum magna quis feugiat tempus. Nunc sit amet mauris a lectus ullamcorper scelerisque. Cras non eros ut sapien facilisis faucibus. Mauris scelerisque et tellus eget semper. Donec accumsan libero vitae justo ultricies, vel lacinia elit tincidunt. Vivamus mattis ullamcorper efficitur. Duis tempor, ligula nec mollis dictum, neque urna vehicula risus, vel tempor tortor nibh sit amet purus. Nunc scelerisque massa nec orci cursus commodo. Vivamus aliquet nisi at elit porttitor gravida. In hac habitasse platea dictumst. Ut vitae leo commodo, scelerisque magna dignissim, sodales diam. Aliquam sed purus imperdiet, ornare ante tincidunt, posuere magna. Aliquam volutpat lectus eu ipsum pharetra volutpat.
        </p>
    </div>

<?php include('views/elements/footer.php'); ?>