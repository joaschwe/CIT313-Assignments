<?php include('views/elements/header.php'); ?>

<div class="container">
    <div class="page-header">
        <h1>Login</h1>
        <?php echo $numbers; ?>
        <?php include('views/elements/login_form.php'); ?>
    </div>
</div>

<?php include('views/elements/footer.php'); ?>
