<?php
/**
 * Created by PhpStorm.
 * User: joanna_schweiger
 * Date: 2/25/18
 * Time: 7:11 PM
 */

ini_set('display_errors', 1);
error_reporting(E_ALL);

require 'application/router.php';