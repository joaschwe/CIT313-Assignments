<?php
class LogoutController extends Controller{

}